package Steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import Database_connectivity.OTP_authentication;
import XPaths.Copartnerlink_xpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Welcome_to_copartner_link 
{ 
	public Copartnerlink_xpath xpath;
	public WebDriver driver;
	public OTP_authentication otp;
	
	@Given("Open browser")
	public void open_browser()
	{
		WebDriverManager.firefoxdriver().setup();
	    driver=new FirefoxDriver();
		driver.manage().window().maximize();
		xpath=new Copartnerlink_xpath(driver);
	  
	}

	@Then("Enter url {string}")
	public void enter_url(String url) throws Exception 
	{
		Thread.sleep(2000);
		driver.get(url);
		
	}

	@When("Welcome to Credit Fair page")
	public void welcome_to_credit_fair_page() throws Exception 
	{
	   xpath.copartnerdetails();
	   Thread.sleep(2000);
	   
	}

	@When("Address details page")
	public void address_details_page() throws Exception 
	{
	    xpath.address_details();
	    Thread.sleep(2000);
	    
	    
	}

	@Then("Employement information page")
	public void employement_information_page() throws Exception 
	{
	    xpath.employment_details();
	    Thread.sleep(2000);
	   
	}

	@Then("Upload Applicant documents page")
	public void upload_applicant_documents_page() throws Exception 
	{
	    xpath.document_upload();
	    Thread.sleep(2000);
	    driver.quit();
	}


	
}
