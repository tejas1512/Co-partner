package step_execute;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)

@CucumberOptions(
	   features="/Users/tejas/Downloads/Partner_link/Copartner_link_automation/src/test/java/features_file",
		glue= "Steps",
		dryRun = false,
		monochrome = true,
	    plugin = {"pretty","io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"}
		
		
		)


public class Steps_runner 
{

}
