package Database_connectivity;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.checkerframework.common.reflection.qual.ForName;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//import java.sql.*;
import com.mysql.jdbc.Driver;

import XPaths.Copartnerlink_xpath;



public class OTP_authentication{
	 
	public String otp;
			

	public void Db_connect() throws Exception {

		
	
		
		Class.forName("com.mysql.jdbc.Driver");
		
		System.out.println("Driver loaded");
		
		@SuppressWarnings("unused")
		
		Connection con = DriverManager.getConnection("jdbc:mysql://cfwebbetanew1.cyc1x9kcl7ju.ap-south-1.rds.amazonaws.com:3306/cfwebbeta","tejas","JM74W<)aQK8?0LZ");
		
		System.out.println("Connected to stage DB");
		
		Statement smt = con.createStatement();
		
		ResultSet rs = smt.executeQuery("select otp from otp_manager where mobile_number = 7900169370 Order BY id DESC LIMIT 1");
		
	  while (rs.next()) {
	   	
	  	otp = rs.getString("otp");
	  	
	   	System.out.println(" "+otp);
	   	  
		}
	  con.close();
	}
}
	
		
	
	
	 



