package XPaths;

import java.sql.SQLException;

import org.apache.velocity.runtime.parser.node.ASTComparisonNode;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
//import org.junit.jupiter.api.Assertions;


import com.mysql.jdbc.Driver;

import Database_connectivity.OTP_authentication;

public class Copartnerlink_xpath extends OTP_authentication
{
	private static final String Assertions = null;
	WebDriver ldriver;
	  public OTP_authentication database;
	  String filepath="/Users/tejas/Downloads/ss1.png";
	
 
	public Copartnerlink_xpath(WebDriver rDriver) {

		ldriver=rDriver;
		PageFactory.initElements(rDriver,this);
	}

	@FindBy (xpath = "//input[@name=\"name\"]")
	 WebElement name;
	
	@FindBy (xpath = "//input[@name=\"pan_card\"]")
	 WebElement pan_card;
	
	@FindBy (xpath = "//input[@name=\"email\"]")
	 WebElement email;
	
	@FindBy (xpath = "//input[@id=\"mobile_number\"]")
	 WebElement mobile_number;
	
	@FindBy (xpath = "//a[@class=\"verify_number\"]")
	 WebElement verify_number;
	
	@FindBy (xpath = "(//input[@type=\"text\"])[5]")
	 WebElement enter_otp;
	
	@FindBy (xpath = "//a[@id=\"verify_otp\"]")
	 WebElement submit_otp;
	
	@FindBy (xpath = "//span[text()=\"CHOOSE PURPOSE *\"]")
	 WebElement choose_purpose;	
	
	@FindBy (xpath = "//input[@type=\"search\"]")
	 WebElement choose_purpose_search;	
	
	@FindBy (xpath = "//span[text()=\"Name of Merchant *\"]")
	 WebElement name_of_merchant;
	
	@FindBy (xpath = "	//input[@type=\"search\"]")
	 WebElement search_merchant;	
	
	
	@FindBy (xpath = "//input[@id=\"product_name\"]")
	 WebElement product_name;
	
	
	@FindBy (xpath = "//input[@id=\"unique_id_number\"]")
	 WebElement unique_id_number;
	
	@FindBy (xpath = "//input[@id=\"duration_year\"]")
	 WebElement duration_year;
	
	@FindBy (xpath = "//input[@id=\"duration_month\"]")
	 WebElement duration_month;
	
	@FindBy (xpath = "//input[@name=\"loan_amount\"]")
	 WebElement loan_amount;
	
	@FindBy (xpath = "(//input[@type=\"text\"])[22]")
	 WebElement select_month;
	
	@FindBy (xpath = "//span[text()=\"9 Months\"]")
	 WebElement select_tenure;
	
	
	@FindBy (xpath = "(//input[@type=\"text\"])[23]")
	 WebElement select_otherdetails;
	
	@FindBy (xpath = "//span[text()=\"English\"]")
	 WebElement select_preferred_language;
	
	@FindBy (xpath = "(//input[@type=\"text\"])[24]")
	 WebElement select_about;
	
	@FindBy (xpath = "//span[text()=\"Social Media\"]")
	 WebElement select_about1;
	
	@FindBy (xpath = "(//button[@type=\"submit\"])[1]")
	 WebElement submitbutton;
	
	
//Address details
	@FindBy (xpath = "(//input[@type=\"text\"])[26]")
	 WebElement sel_year;

	@FindBy (xpath = "//span[text()=\"1995\"]")
	 WebElement sel_y;
	
	@FindBy (xpath = "(//input[@type=\"text\"])[27]")
	 WebElement sel_month;

	@FindBy (xpath = "//span[text()=\"12\"]")
	 WebElement sel_mm;
	
	@FindBy (xpath = "(//input[@type=\"text\"])[28]")
	 WebElement sel_day;
	
	@FindBy (xpath = "//span[text()=\"15\"]")
	 WebElement sel_d;
	
	
	@FindBy (xpath = "((//div)[107]/div[1])")
	 WebElement sel_gender;
	
	@FindBy (xpath = "(//input[@type=\"text\"])[29]")
	 WebElement sel_marital_status;
	
	@FindBy (xpath = "//span[text()=\"SINGLE\"]")
	 WebElement sel_S;
	
	@FindBy (xpath = "//input[@name=\"current_address_line_1\"]")
	 WebElement sel_current_address;
	
	
	@FindBy (xpath = "(//span[text()=\"State *\"])[1]")
	 WebElement sel_state;
	
	@FindBy (xpath = "//input[@type=\"search\"]")
	 WebElement search_state;
	
	@FindBy (xpath = "	//input[@name=\"current_address_city\"]")
	 WebElement current_address_city;
	

	@FindBy (xpath = "//input[@name=\"current_address_pincode\"]")
	 WebElement current_address_pincode;
	
	@FindBy (xpath = "//input[@name=\"current_address_landmark\"]")
	 WebElement current_address_landmark;
	
	@FindBy (xpath = "(//input[@type=\"text\"])[34]")
	 WebElement current_address_status;
	
	
	@FindBy (xpath = "//span[text()=\"OWNED\"]")
	 WebElement sel_address_status;
	
	@FindBy (xpath = "//input[@name=\"alt_contact_number\"]")
	 WebElement alt_contact_number;
	
	@FindBy (xpath = "(//button[@type=\"submit\"])[2]")
	 WebElement submit_next;
	
	

	//Employment details
	
	@FindBy (xpath = "(//input[@type=\"text\"])[40]")
	 WebElement select_employment_status;
	
	@FindBy (xpath = "//span[text()=\"SALARIED\"]")
	 WebElement select_employment_status_1;
	
	
	@FindBy (xpath = "//input[@name=\"monthly_income\"]")
	 WebElement monthly_income;
	

	@FindBy (xpath = "//input[@name=\"company_name\"]")
	 WebElement company_name;
	
	
	@FindBy (xpath = "(//button[@type=\"submit\"])[3]")
	 WebElement submit_next_1;
	
	
	//Upload documents
	
	
	@FindBy (xpath = "(//input[@name=\"file_pan_card\"])[1]")
	 WebElement pancard_upload ;
	
	
	@FindBy (xpath = "(//input[@name=\"file_aadhaar_card\"])[1]")
	 WebElement aadharcard_upload ;
	
	
	@FindBy (xpath = "(//input[@name=\"file_aadhaar_card_back\"])[1]")
	 WebElement aadharcardback_upload ;
	
	@FindBy (xpath = "(//button[@type=\"submit\"])[5]")
	 WebElement submit_apply ;
	
	
	
	public void copartnerdetails() throws Exception, Exception
	
	
	{ 
		Thread.sleep(2000);
		name.sendKeys("credittestertejasqaer");
		Thread.sleep(1000);
		pan_card.sendKeys("MYTUS9069L");
		Thread.sleep(1000);
		email.sendKeys("tejasshetye00156@creditfair.in");
		Thread.sleep(1000);
		loan_amount.sendKeys("50000");
		Thread.sleep(1000);
		 choose_purpose.click();
		Thread.sleep(1000);
		choose_purpose_search.click();
		choose_purpose_search.sendKeys("Edu");
		choose_purpose_search.sendKeys(Keys.ENTER);
		Thread.sleep(4000);
		name_of_merchant.click();
		Thread.sleep(1000);
		search_merchant.click();
		search_merchant.sendKeys("teja");
		search_merchant.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		product_name.sendKeys("test");
		Thread.sleep(1000);
		unique_id_number.sendKeys("108108");
		Thread.sleep(1000);
		mobile_number.sendKeys("7900169370");
		Thread.sleep(1000);
		verify_number.click();
		Thread.sleep(1000);
		enter_otp.click();
		super.Db_connect();
		System.out.println(otp);	
		Thread.sleep(1000);
		enter_otp.sendKeys(otp);
		Thread.sleep(1000);
		submit_otp.click();
		Thread.sleep(2000);
	    duration_year.sendKeys("1");
	    duration_month.sendKeys("0");
	    Thread.sleep(1000);
	    select_month.click();
	    Thread.sleep(1000);
	    select_tenure.click();
	    Thread.sleep(1000);
	    select_otherdetails.click();
	    Thread.sleep(1000);
	    select_preferred_language.click();
	    Thread.sleep(1000);
	    select_about.click();
	    select_about1.click();
	    Thread.sleep(1000);
	    submitbutton.click();
	    
	 
	   
		
		
	}
	
	@Test
	public void address_details() throws Exception {
		Thread.sleep(2000);
		sel_year.click();
		Thread.sleep(1000);
		sel_y.click();
		Thread.sleep(1000);
		sel_month.click();
		Thread.sleep(1000);
		sel_mm.click();
		Thread.sleep(1000);
		sel_day.click();
		Thread.sleep(1000);
		sel_d.click();
		Thread.sleep(1000);
		sel_gender.click();
		Thread.sleep(1000);
		sel_marital_status.click();
		Thread.sleep(1000);
		sel_S.click();
		Thread.sleep(1000);
		sel_current_address.sendKeys("parel");
		Thread.sleep(1000);
		sel_state.click();
		search_state.click();
		Thread.sleep(1000);
		search_state.sendKeys("Maha");
		search_state.sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		current_address_city.sendKeys("Mumbai");
		Thread.sleep(1000);
		current_address_pincode.sendKeys("400012");
		Thread.sleep(1000);
		current_address_landmark.sendKeys("ITC Grand Hotel");
		Thread.sleep(1000);
		current_address_status.click();
		Thread.sleep(1000);
		sel_address_status.click();
		Thread.sleep(1000);
		alt_contact_number.sendKeys("9029007654");
		Thread.sleep(1000);
        submit_next.click();	
	

	
	}
	
	
	public void employment_details() throws Exception
	{
		Thread.sleep(1000);
		select_employment_status.click();
		Thread.sleep(1000);
		select_employment_status_1.click();
		Thread.sleep(1000);
		monthly_income.sendKeys("50000");
		Thread.sleep(1000);
		company_name.sendKeys("Credit Fair");
		Thread.sleep(1000);
		submit_next_1.click();
		
		
	}
	
	public void document_upload() throws Exception 
	
	{
		Thread.sleep(2000);
		WebElement fileupload=ldriver.findElement(By.xpath("(//input[@name=\"file_pan_card\"])[2]"));
		fileupload.sendKeys("/Users/tejas/Downloads/ss1.png");
	
		Thread.sleep(2000);
		WebElement fileupload1=ldriver.findElement(By.xpath("(//input[@name=\"file_aadhaar_card\"])[2]"));
		fileupload1.sendKeys("/Users/tejas/Downloads/ss1.png");
		Thread.sleep(2000);
		WebElement fileupload2=ldriver.findElement(By.xpath("(//input[@name=\"file_aadhaar_card_back\"])[2]"));
		fileupload2.sendKeys("/Users/tejas/Downloads/ss1.png");
		Thread.sleep(2000);
		submit_apply.click();
		
	}
	
}
